DROP TABLE `iptocountry`;
DROP TABLE `activation_codes`;
DROP TABLE `player_settings`;
DROP TABLE `playeraudio_settings`;

RENAME TABLE `playlist_video` TO `history_video`;
RENAME TABLE `playlist_image` TO `history_image`;
RENAME TABLE `playlist_audio` TO `history_audio`;

ALTER TABLE `comm_vid` ADD `approved` INT( 1 ) NOT NULL DEFAULT '1';
ALTER TABLE `comm_img` ADD `approved` INT( 1 ) NOT NULL DEFAULT '1';
ALTER TABLE `comm_audio` ADD `approved` INT( 1 ) NOT NULL DEFAULT '1';
ALTER TABLE `comm_profile` ADD `approved` INT( 1 ) NOT NULL DEFAULT '1';
ALTER TABLE `languages` ADD `cflag` VARCHAR( 100 ) NOT NULL DEFAULT 'United Kingdom';
INSERT INTO `languages` (`id`, `name`, `file`, `active`, `def`, `cflag`) VALUES (17, 0xc3a4c2b8c2adc3a6e28093e280a1, 0x6368696e6573652e706870, 1, 0, 0x4368696e61);
INSERT INTO `languages` (`id`, `name`, `file`, `active`, `def`, `cflag`) VALUES (18, 0x45737061c383c2b16f6c, 0x7370616e6973682e706870, 1, 0, 0x537061696e);
INSERT INTO `languages` (`id`, `name`, `file`, `active`, `def`, `cflag`) VALUES (19, 0x4672616ec383c2a7616973, 0x6672656e63682e706870, 1, 0, 0x4672616e6365);
INSERT INTO `languages` (`id`, `name`, `file`, `active`, `def`, `cflag`) VALUES (20, 0x4475746368, 0x64757463682e706870, 1, 0, 0x4e65746865726c616e6473);
UPDATE `languages` set cflag='Israel' where file='hebrew.php';
UPDATE `languages` set cflag='Poland' where file='polish.php';
UPDATE `languages` set cflag='Bosnia and Herzegovina' where file='bosnian.php';
UPDATE `languages` set cflag='Croatia' where file='croatian.php';
UPDATE `languages` set cflag='Serbia and Montenegro' where file='serbian.php';
UPDATE `languages` set cflag='Armenia' where file='armenian.php';
UPDATE `configurations` set configurations.value='metube' where configurations.option='site_theme';

INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('enable_channels', '1', 'Setting to control if the Channels module is enabled/disabled');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('categ_counts', '1', 'Setting to control if category file counts are displayed!');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('channel_counts', '1', 'Setting to control if channel type counts are displayed!');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('views_delim', 'comma', 'Setting to control the file views delimiter');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('path_ffmpeg', '/usr/bin/ffmpeg', 'Path to FFmpeg');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('thumb_method', 'ffmpeg', 'Setting to control the thumbnail creationd method.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('thumb_module', '1', 'Setting to control if the thumbnail animation module is enabled.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('thumb_nr', '3', 'Setting to control how many thumbnails will be grabbed for the animation mod.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('thumb_delay', '500', 'Setting to control the delay between the thumbnail change.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('thumb_order', 'cons', 'Setting to control if consecutive or random thumbnails should be grabbed.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('thumb_bg', '', 'Setting to control the thumbnail background color.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('conv_tool', 'mencoder', 'Setting to control the default video conversion tool.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('username_recovery', '1', 'Setting to control if username recovery is allowed.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('password_recovery', '1', 'Setting to control if password recovery is allowed.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('recoverylinktime', '12', 'Setting to control how long the password verification link is active.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('recoverytimer', '1', 'Setting to control if the password reset link timer is displayed.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('word_filters', '1', 'Setting to control if word filtering is enabled.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('repl_string', '*', 'Setting to control the word filtering replacement string.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('comment_rating', '1', 'Setting to control if comment ratings are allowed.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('file_responses', '1', 'Setting to control if file responses are allowed.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('multi_categ_uploads', '0', 'Setting to control if uploading is allowed in more than one category.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('multi_categ_max', '3', 'Setting to control in how many categories uploading is allowed in.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('same_title_uploads', '0', 'Setting to control if files with the same title are allowed.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('emails_per_hour', '3', 'Setting to control how many emails per hour can be sent from the same IP using the "share channel" function.');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('subscribe_files_not', '1', 'Setting to control email notifications: Notify members about new subscriptions');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('file_response_not', '1', 'Setting to control email notifications: Notify members about new file responses');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('paging_mysubs', '12', 'Setting to control the paging for My Subscriptions');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('paging_myusubs', '10', 'Setting to control the paging for My Subscribers');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('paging_fileresp', '10', 'Setting to control the paging for File Responses');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('paging_qlist', '12', 'Setting to control the paging for My Quicklist');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('paging_plist', '12', 'Setting to control the paging for My Playlists');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('paging_plist2', '12', 'Setting to control the paging for Playlist Details');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('paging_chan', '19', 'Setting to control the paging for Channels');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('guests_chan_access', '1', 'Setting to control if the guest account can access the channels section');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('inc_aplayer_count', '0', 'Setting to control if the audio file view count is incremented when embedded videos are accessed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('inc_vplayer_count', '0', 'Setting to control if the video file view count is incremented when embedded videos are accessed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('mail_not_ch', '1', 'Setting to control email notifications: Notify admin about new channel requests');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_pcnbox', '1', 'Setting to control the Previous/Current/Next Box');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_pcnbox_pos', 'right', 'Setting to control the Previous/Current/Next Box position');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_userdate', 'reg', 'Setting to control the user details: show registration date or last login');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_useronline', '1', 'Setting to control the user details: show online status');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_userfcount', '1', 'Setting to control the user details: user file count');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_fdesc', 'e', 'Setting to control the file description: collapsed or expanded');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_ftabs', '1', 'Setting to control if the file tabs are enabled');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_ftabslist', '1', 'Setting to control on how many colums to display tab results');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_ftabs_t1', '1', 'Setting to control which tabs are enabled: related tab');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_ftabs_t5', '1', 'Setting to control which tabs are enabled: by this user tab');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_ftags', '1', 'Setting to control if related tags are displayed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_ftags_box', 'e', 'Setting to control if the related tags box is expanded or collapsed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_fcomm_box', 'e', 'Setting to control if the comments box is expanded or collapsed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_fresp_box', 'e', 'Setting to control if the responses box is expanded or collapsed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_fqlist_box', 'e', 'Setting to control if the quicklist box is expanded or collapsed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_fplist_box', 'e', 'Setting to control if the playlist box is expanded or collapsed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_ftabs_t1_box', 'e', 'Setting to control if the related box is expanded or collapsed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('vpage_ftabs_t5_box', 'e', 'Setting to control if the user tab is expanded or collapsed');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('conv_deny_w', '1024', 'Setting to control image conversion settings');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('conv_deny_h', '768', 'Setting to control image conversion settings');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('conv_resize_than_w', '1024', 'Setting to control image conversion settings');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('conv_resize_than_h', '768', 'Setting to control image conversion settings');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('conv_resize_to_w', '800', 'Setting to control image conversion settings');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('conv_resize_to_h', '600', 'Setting to control image conversion settings');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('img_scale', 'any', 'Setting to control the width/height criteria for allowing images to be uploaded');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('pltitle_min', '3', 'Setting to control playlist title min. length');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('pltitle_max', '20', 'Setting to control playlist title max. length');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('thimgwidth', '165', 'Setting to control table header image width');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('max_bgimage', '262144', 'Setting to control max. size for the user channel background image, in bytes');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('landing_page', '1', 'Setting to control if the custom landing page is enabled');
INSERT INTO `configurations` ( `option` , `value` , `description` ) VALUES ('date_selection', 'html', 'Setting to control the date selection display');

CREATE TABLE `activation_codes` (
  `uid` bigint(20) NOT NULL default '0',
  `code` varchar(50) collate utf8_bin NOT NULL,
  `fcode` varchar(20) collate utf8_bin NOT NULL,
  `photo` varchar(100) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `player_settings` (
  `ID` bigint(20) NOT NULL default '0',
  `autoplay` int(5) NOT NULL default '1',
  `theme` varchar(25) collate utf8_bin NOT NULL,
  `share` int(5) NOT NULL default '0',
  `repeats` int(5) NOT NULL default '0',
  `advertisement` int(5) NOT NULL default '0',
  `playlist` varchar(10) collate utf8_bin NOT NULL default 'rel',
  `poption` int(5) NOT NULL default '0',
  `pwidth` int(3) NOT NULL default '320',
  `pheight` int(3) NOT NULL default '240',
  `embed` int(1) NOT NULL default '1',
  `mail` int(1) NOT NULL default '1',
  `vads` int(1) NOT NULL default '1',
  `tads` int(1) NOT NULL default '1',
  `btime` int(3) NOT NULL default '10',
  `atime` int(3) NOT NULL default '5',
  `fullscreen` int(1) NOT NULL default '1',
  `logo` int(1) NOT NULL default '1',
  `pb` int(1) NOT NULL default '1',
  `color_related` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_embed` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_share` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_mail` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_replay` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_time` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_copy` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_ta1` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_ta2` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_ta3` varchar(7) collate utf8_bin NOT NULL default '999999',
  `color_ta4` varchar(7) collate utf8_bin NOT NULL default '999999'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `player_settings` (`ID`, `autoplay`, `theme`, `share`, `repeats`, `advertisement`, `playlist`, `poption`, `pwidth`, `pheight`, `embed`, `mail`, `vads`, `tads`, `btime`, `atime`, `fullscreen`, `logo`, `pb`, `color_related`, `color_embed`, `color_share`, `color_mail`, `color_replay`, `color_time`, `color_copy`, `color_ta1`, `color_ta2`, `color_ta3`, `color_ta4`) VALUES 
(1, 0, 0x626c61636b, 0, 0, 2, 0x66656174, 0, 630, 385, 0, 1, 1, 1, 5, 2, 1, 1, 1, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939),
(2, 0, 0x626c61636b, 1, 1, 2, 0x66656174, 0, 320, 240, 1, 0, 0, 0, 10, 3, 0, 1, 1, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939, 0x393939393939);

CREATE TABLE `playeraudio_settings` (
  `ID` bigint(20) NOT NULL default '0',
  `autoplay` int(5) NOT NULL default '1',
  `skin` varchar(50) collate utf8_bin NOT NULL default 'def',
  `pwidth` int(3) NOT NULL default '320',
  `pheight` int(3) NOT NULL default '240',
  `wwidth` int(3) NOT NULL default '120',
  `wheight` int(3) NOT NULL default '90',
  `bgimage` varchar(30) collate utf8_bin NOT NULL,
  `logo` int(1) NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `playeraudio_settings` (`ID`, `autoplay`, `skin`, `pwidth`, `pheight`, `wwidth`, `wheight`, `bgimage`, `logo`) VALUES 
(1, 0, 0x726e64, 630, 385, 120, 90, '', 1),
(2, 0, 0x736e656c2e737766, 320, 240, 120, 90, '', 1);

INSERT INTO `email_files` (`email_id` ,`email_subject` ,`email_path` ,`comment`) VALUES ('user_recover', 'Your $config[site_name] username!', 'emails/user_recover.tpl', 'Username Recovery Message');
INSERT INTO `email_files` (`email_id` ,`email_subject` ,`email_path` ,`comment`) VALUES ('admin_recover', 'Your Admin Panel Password!', 'emails/admin_recover.tpl', 'Admin Password Recovery Message');
INSERT INTO `email_files` (`email_id` ,`email_subject` ,`email_path` ,`comment`) VALUES ('share_channel', 'Check out this $config[site_name] channel!', 'emails/share_channel.tpl', 'Share Channel Message');
INSERT INTO `email_files` (`email_id` ,`email_subject` ,`email_path` ,`comment`) VALUES ('report_channel', 'New $rtype request!', 'emails/report_channel.tpl', 'Report Profile/Background Image Message');
INSERT INTO `email_files` (`email_id` ,`email_subject` ,`email_path` ,`comment`) VALUES ('subscribe_files', '$username has subscribed to your $subtypes', 'emails/subscribe_files.tpl', 'Subscribe Message');
INSERT INTO `email_files` (`email_id` ,`email_subject` ,`email_path` ,`comment`) VALUES ('file_responses', 'New $rtype response to "$title"', 'emails/file_responses.tpl', 'File Response Notification');
INSERT INTO `email_files` (`email_id` ,`email_subject` ,`email_path` ,`comment`) VALUES ('share_playlist', '$username sent you a playlist: "$title"', 'emails/share_playlist.tpl', 'Share Playlist Message');
INSERT INTO `adv_site` (`aid` ,`aname` ,`adescr` ,`astatus` ,`afilename`) VALUES ('16', 'ads_channel', 'The Channels Advertisement Area', '1', 'ads/channel_ads.tpl');

ALTER TABLE `history_video` CHANGE `added` `addtime` VARCHAR( 20 ) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;
ALTER TABLE `history_image` CHANGE `added` `addtime` VARCHAR( 20 ) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;
ALTER TABLE `history_audio` CHANGE `added` `addtime` VARCHAR( 20 ) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;

ALTER TABLE `files_video` ADD `is_commrate` VARCHAR( 10 ) NOT NULL DEFAULT 'yes' AFTER `is_bm` , ADD `is_fileresp` VARCHAR( 10 ) NOT NULL DEFAULT 'yes' AFTER `is_commrate`;
ALTER TABLE `files_image` ADD `is_commrate` VARCHAR( 10 ) NOT NULL DEFAULT 'yes' AFTER `is_bm` , ADD `is_fileresp` VARCHAR( 10 ) NOT NULL DEFAULT 'yes' AFTER `is_commrate`;
ALTER TABLE `files_audio` ADD `is_commrate` VARCHAR( 10 ) NOT NULL DEFAULT 'yes' AFTER `is_bm` , ADD `is_fileresp` VARCHAR( 10 ) NOT NULL DEFAULT 'yes' AFTER `is_commrate`;
ALTER TABLE `files_video` CHANGE `is_comm` `is_comm` VARCHAR( 10 ) NOT NULL DEFAULT 'yes', CHANGE `is_rated` `is_rated` VARCHAR( 10 ) NOT NULL DEFAULT 'yes', CHANGE `is_embed` `is_embed` VARCHAR( 10 ) NOT NULL DEFAULT 'yes', CHANGE `is_bm` `is_bm` VARCHAR( 10 ) NOT NULL DEFAULT 'yes';
ALTER TABLE `files_image` CHANGE `is_comm` `is_comm` VARCHAR( 10 ) NOT NULL DEFAULT 'yes', CHANGE `is_rated` `is_rated` VARCHAR( 10 ) NOT NULL DEFAULT 'yes', CHANGE `is_embed` `is_embed` VARCHAR( 10 ) NOT NULL DEFAULT 'yes', CHANGE `is_bm` `is_bm` VARCHAR( 10 ) NOT NULL DEFAULT 'yes';
ALTER TABLE `files_audio` CHANGE `is_comm` `is_comm` VARCHAR( 10 ) NOT NULL DEFAULT 'yes', CHANGE `is_rated` `is_rated` VARCHAR( 10 ) NOT NULL DEFAULT 'yes', CHANGE `is_embed` `is_embed` VARCHAR( 10 ) NOT NULL DEFAULT 'yes', CHANGE `is_bm` `is_bm` VARCHAR( 10 ) NOT NULL DEFAULT 'yes';
ALTER TABLE `files_video` ADD `responses` BIGINT( 20 ) NOT NULL DEFAULT '0' AFTER `views`;
ALTER TABLE `files_image` ADD `responses` BIGINT( 20 ) NOT NULL DEFAULT '0' AFTER `views`;
ALTER TABLE `files_audio` ADD `responses` BIGINT( 20 ) NOT NULL DEFAULT '0' AFTER `views`;
ALTER TABLE `files_video` ADD `vl_title` TEXT NOT NULL AFTER `vdescr`, ADD `vl_descr` TEXT NOT NULL AFTER `vl_title`;
ALTER TABLE `files_image` ADD `vl_title` TEXT NOT NULL AFTER `vdescr`, ADD `vl_descr` TEXT NOT NULL AFTER `vl_title`;
ALTER TABLE `files_audio` ADD `vl_title` TEXT NOT NULL AFTER `vdescr`, ADD `vl_descr` TEXT NOT NULL AFTER `vl_title`;

ALTER TABLE `members` CHANGE `name` `fname` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;
ALTER TABLE `members` ADD `lname` VARCHAR( 100 ) NOT NULL AFTER `fname`; 
ALTER TABLE `members` CHANGE `location` `inf_city` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;
ALTER TABLE `members` CHANGE `descr` `descr` LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;

ALTER TABLE `members` ADD `rel_status` VARCHAR( 20 ) NOT NULL ,
ADD `show_age` VARCHAR( 3 ) NOT NULL DEFAULT 'yes',
ADD `about_me` LONGTEXT NOT NULL ,
ADD `inf_occup` MEDIUMTEXT NOT NULL ,
ADD `inf_comp` MEDIUMTEXT NOT NULL ,
ADD `inf_schools` MEDIUMTEXT NOT NULL ,
ADD `inf_interests` LONGTEXT NOT NULL ,
ADD `inf_movies` MEDIUMTEXT NOT NULL ,
ADD `inf_music` MEDIUMTEXT NOT NULL ,
ADD `inf_books` MEDIUMTEXT NOT NULL ,
ADD `inf_town` VARCHAR( 30 ) NOT NULL ,
ADD `inf_zip` BIGINT( 30 ) NOT NULL ;

ALTER TABLE `members` ADD `ch_title` VARCHAR( 100 ) NOT NULL ,
ADD `ch_desc` LONGTEXT NOT NULL ,
ADD `ch_tags` VARCHAR( 200 ) NOT NULL ,
ADD `ch_comm` VARCHAR( 3 ) NOT NULL DEFAULT 'yes',
ADD `ch_comm_who` VARCHAR( 30 ) NOT NULL DEFAULT '0',
ADD `ch_type` VARCHAR( 30 ) NOT NULL DEFAULT '1',
ADD `ch_vids` LONGTEXT NOT NULL ,
ADD `ch_favs` LONGTEXT NOT NULL ;

ALTER TABLE `members` ADD `bl_files` VARCHAR( 3 ) NOT NULL DEFAULT 'yes', ADD `bl_chcomm` VARCHAR( 3 ) NOT NULL DEFAULT 'yes', ADD `bl_chan` VARCHAR( 3 ) NOT NULL DEFAULT 'yes', ADD `bl_msg` VARCHAR( 3 ) NOT NULL DEFAULT 'yes';
ALTER TABLE `members` ADD `bl_sub` VARCHAR( 3 ) NOT NULL DEFAULT 'yes';
ALTER TABLE `members` ADD `ch_imgs` LONGTEXT NOT NULL AFTER `ch_vids` , ADD `ch_auds` LONGTEXT NOT NULL AFTER `ch_imgs`;
ALTER TABLE `members` CHANGE `ch_favs` `ch_vfavs` LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin NOT NULL;
ALTER TABLE `members` ADD `ch_ifavs` LONGTEXT NOT NULL AFTER `ch_vfavs` , ADD `ch_afavs` LONGTEXT NOT NULL AFTER `ch_ifavs`;
ALTER TABLE `members` ADD `ch_commrate` INT( 1 ) NOT NULL DEFAULT '1' AFTER `ch_comm_who`;
ALTER TABLE `members` ADD `ch_views` BIGINT( 20 ) NOT NULL DEFAULT '0' AFTER `ch_afavs`;
ALTER TABLE `members` ADD `inf_eurl` VARCHAR( 100 ) NOT NULL AFTER `inf_zip` , ADD `inf_etitle` VARCHAR( 100 ) NOT NULL AFTER `inf_eurl`;
ALTER TABLE `members` ADD `show_status` VARCHAR( 3 ) NOT NULL DEFAULT 'yes' AFTER `show_age`;
ALTER TABLE `members` ADD `ch_subs` BIGINT( 20 ) NOT NULL DEFAULT '0' AFTER `ch_views`;
ALTER TABLE `members` ADD `can_upload` INT NOT NULL DEFAULT '1';
 
CREATE TABLE `member_info` (
`p_id` BIGINT( 20 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`p_type` VARCHAR( 50 ) NOT NULL ,
`p_about` LONGTEXT NOT NULL ,
`p_style` LONGTEXT NOT NULL ,
`p_infl` LONGTEXT NOT NULL ,
`p_sim` LONGTEXT NOT NULL ,
`p_bandmem` LONGTEXT NOT NULL ,
`p_formdate` DATE NOT NULL ,
`p_reclabel` LONGTEXT NOT NULL ,
`p_labeltype` LONGTEXT NOT NULL ,
`p_a1cover` LONGTEXT NOT NULL ,
`p_a1order` LONGTEXT NOT NULL ,
`p_a2cover` LONGTEXT NOT NULL ,
`p_a2order` LONGTEXT NOT NULL ,
`p_a3cover` LONGTEXT NOT NULL ,
`p_a3order` LONGTEXT NOT NULL ,
`p_uid` BIGINT( 20 ) NOT NULL
) ENGINE = MYISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
ALTER TABLE `member_info` ADD UNIQUE `uni` ( `p_uid` );

CREATE TABLE `member_shows` (
`s_id` BIGINT( 20 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`s_key` VARCHAR( 20 ) NOT NULL ,
`s_uid` BIGINT( 20 ) NOT NULL ,
`s_date` DATE NOT NULL ,
`s_timeh` INT( 2 ) NOT NULL ,
`s_timem` INT( 2 ) NOT NULL ,
`s_venue` VARCHAR( 100 ) NOT NULL ,
`s_addr` LONGTEXT NOT NULL ,
`s_city` VARCHAR( 50 ) NOT NULL ,
`s_zip` VARCHAR( 50 ) NOT NULL ,
`s_country` VARCHAR( 100 ) NOT NULL ,
`s_descr` LONGTEXT NOT NULL ,
`s_ticket` VARCHAR( 100 ) NOT NULL ,
`active` INT( 1 ) NOT NULL default '1'
) ENGINE = MYISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `member_theme` (
  `th_id` bigint(20) NOT NULL auto_increment,
  `th_uid` bigint(20) NOT NULL,
  `th_theme` varchar(50) collate utf8_bin NOT NULL,
  `th_featvid` int(1) NOT NULL default '1',
  `th_featvid_type` VARCHAR (200) NOT NULL default 'v',
  `th_featvid_file` VARCHAR (200) NOT NULL default 'last',
  `th_subs` int(1) NOT NULL default '1',
  `th_subspos` varchar(10) collate utf8_bin NOT NULL default 'left',
  `th_plist` int(1) NOT NULL default '1',
  `th_plistchan` varchar(200) collate utf8_bin NOT NULL,
  `th_vid` int(1) NOT NULL default '1',
  `th_vid_view` varchar(10) collate utf8_bin NOT NULL default 'grid',
  `th_vlog` int(1) NOT NULL default '1',
  `th_fav` int(1) NOT NULL default '1',
  `th_fav_view` varchar(10) collate utf8_bin NOT NULL default 'grid',
  `th_usubs` int(1) NOT NULL default '1',
  `th_usubs_pos` varchar(10) collate utf8_bin NOT NULL default 'right',
  `th_friends` int(1) NOT NULL default '1',
  `th_friends_pos` varchar(10) collate utf8_bin NOT NULL default 'right',
  `th_comm` int(1) NOT NULL default '1',
  `th_comm_pos` varchar(10) collate utf8_bin NOT NULL default 'right',
  `th_bgcol` varchar(10) collate utf8_bin NOT NULL default '#2C405B',
  `th_bgimage` varchar(50) collate utf8_bin NOT NULL default 'none',
  `th_bgsrcname` varchar(500) collate utf8_bin NOT NULL,
  `th_bgrpt` int(1) NOT NULL default '1',
  `th_link` varchar(10) collate utf8_bin NOT NULL default '#6B8AB8',
  `th_link_dec` int(1) NOT NULL default '1',
  `th_label` varchar(10) collate utf8_bin NOT NULL default '#EBEFF0',
  `th_transp` int(3) NOT NULL default '100',
  `th_font_fam` varchar(30) collate utf8_bin NOT NULL default 'Arial',
  `th_font_size` int(1) NOT NULL default '10',
  `th_hb_bgcol` varchar(10) collate utf8_bin NOT NULL default '#EBEFF0',
  `th_hb_h1` varchar(10) collate utf8_bin NOT NULL default '#FFFFFF',
  `th_hb_h2` varchar(10) collate utf8_bin NOT NULL default '#6B8AB8',
  `th_bb_border` varchar(10) collate utf8_bin NOT NULL default '#6B8AB8',
  `th_bb_bgcol` varchar(10) collate utf8_bin NOT NULL default '#2C405B',
  `th_bb_h1` varchar(10) collate utf8_bin NOT NULL default '#FFFFFF',
  `th_bb_h2` varchar(10) collate utf8_bin NOT NULL default '#FFFFFF',
  `th_vl_border` varchar(10) collate utf8_bin NOT NULL default '#2C405B',
  `th_vl_bgcol` varchar(10) collate utf8_bin NOT NULL default '#2C405B',
  `th_vl_post` varchar(10) collate utf8_bin NOT NULL default '#6B8AB8',
  `th_vl_h1` varchar(10) collate utf8_bin NOT NULL default '#FFFFFF',
  `th_vl_h2` varchar(10) collate utf8_bin NOT NULL default '#FFFFFF',
  PRIMARY KEY  (`th_id`),
  UNIQUE KEY `uni` (`th_uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
INSERT INTO `member_theme` (`th_id`, `th_uid`, `th_theme`, `th_featvid`, `th_featvid_type`, `th_featvid_file`, `th_subs`, `th_subspos`, `th_plist`, `th_plistchan`, `th_vid`, `th_vid_view`, `th_vlog`, `th_fav`, `th_fav_view`, `th_usubs`, `th_usubs_pos`, `th_friends`, `th_friends_pos`, `th_comm`, `th_comm_pos`, `th_bgcol`, `th_bgimage`, `th_bgsrcname`, `th_bgrpt`, `th_link`, `th_link_dec`, `th_label`, `th_transp`, `th_font_fam`, `th_font_size`, `th_hb_bgcol`, `th_hb_h1`, `th_hb_h2`, `th_bb_border`, `th_bb_bgcol`, `th_bb_h1`, `th_bb_h2`, `th_vl_border`, `th_vl_bgcol`, `th_vl_post`, `th_vl_h1`, `th_vl_h2`) VALUES (1, 0, 0x64656661756c74, 1, 0x76, 0x6c617374, 1, 0x6c656674, 1, '', 1, 0x67726964, 1, 1, 0x67726964, 1, 0x6c656674, 1, 0x6c656674, 1, 0x7269676874, 0x23324334303542, 0x6e6f6e65, '', 1, 0x23364238414238, 1, 0x23454245464630, 100, 0x417269616c, 12, 0x23454245464630, 0x23464646464646, 0x23364238414238, 0x23364238414238, 0x23324334303542, 0x23464646464646, 0x23464646464646, 0x23324334303542, 0x23324334303542, 0x23364238414238, 0x23464646464646, 0x23464646464646);

CREATE TABLE `email_usage` (
`eid` BIGINT( 20 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`e_ip` VARCHAR( 30 ) NOT NULL ,
`e_time` VARCHAR( 50 ) NOT NULL ,
`e_try` INT( 3 ) NOT NULL DEFAULT '0'
) ENGINE = MYISAM;

CREATE TABLE `file_responses` (
`rid` BIGINT( 20 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`rtype` VARCHAR( 30 ) NOT NULL ,
`rvid` BIGINT( 20 ) NOT NULL ,
`rtovid` BIGINT( 20 ) NOT NULL ,
`ruid` BIGINT( 20 ) NOT NULL ,
`resuid` BIGINT( 20 ) NOT NULL ,
`approved` INT( 1 ) NOT NULL DEFAULT '1', 
`active` INT( 1 ) NOT NULL DEFAULT '1'
) ENGINE = MYISAM;
ALTER TABLE `file_responses` ADD UNIQUE `uni` ( `rtype` , `rvid`, `active` );
ALTER TABLE `file_responses` ADD `rtime` BIGINT( 30 ) NOT NULL AFTER `resuid`;

CREATE TABLE `subscriptions` (
`sid` BIGINT( 20 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`stype` VARCHAR( 30 ) NOT NULL DEFAULT 'user', 
`subscriber_uid` BIGINT( 20 ) NOT NULL ,
`subscriber_name` VARCHAR( 50 ) NOT NULL ,
`subscribed_uid` BIGINT( 20 ) NOT NULL ,
`subscribed_name` VARCHAR( 50 ) NOT NULL ,
`subscription_time` VARCHAR( 100 ) NOT NULL ,
`active` INT( 1 ) NOT NULL DEFAULT '1'
) ENGINE = MYISAM ;
ALTER TABLE `subscriptions` ADD UNIQUE `uni` ( `subscriber_uid` , `subscriber_name` , `subscribed_uid` , `subscribed_name`, `stype` );

CREATE TABLE `quicklist_video` (
  `uid` bigint(20) NOT NULL default '0',
  `vid` bigint(20) NOT NULL default '0',
  `addtime` varchar(20) collate utf8_bin NOT NULL,
  `from_uid` bigint(20) NOT NULL default '0',
  `quicklist_ip` varchar(30) collate utf8_bin NOT NULL default 'none',
  UNIQUE KEY `uid` (`uid`,`vid`,`quicklist_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
CREATE TABLE `quicklist_image` (
  `uid` bigint(20) NOT NULL default '0',
  `vid` bigint(20) NOT NULL default '0',
  `addtime` varchar(20) character set utf8 collate utf8_bin NOT NULL,
  `from_uid` bigint(20) NOT NULL default '0',
  `quicklist_ip` varchar(30) NOT NULL default 'none',
  UNIQUE KEY `uid` (`uid`,`vid`,`quicklist_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE `quicklist_audio` (
  `uid` bigint(20) NOT NULL default '0',
  `vid` bigint(20) NOT NULL default '0',
  `addtime` varchar(20) character set utf8 collate utf8_bin NOT NULL,
  `from_uid` bigint(20) NOT NULL default '0',
  `quicklist_ip` varchar(30) NOT NULL default 'none',
  UNIQUE KEY `uid` (`uid`,`vid`,`quicklist_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `playlist_video` ( `pname` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL , `uid` BIGINT( 20 ) NOT NULL , `from_uid` BIGINT( 20 ) NOT NULL , `vid` BIGINT( 20 ) NOT NULL , `addtime` VARCHAR( 30 ) NOT NULL , `descr` LONGTEXT NOT NULL , `vkey` VARCHAR( 30 ) NOT NULL , `embed` INT( 1 ) NOT NULL DEFAULT '1', `tags` LONGTEXT NOT NULL , `privacy` VARCHAR( 10 ) NOT NULL , `vlog` INT( 1 ) NOT NULL DEFAULT '0' ) ENGINE = MYISAM ;
CREATE TABLE `playlist_image` ( `pname` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL , `uid` BIGINT( 20 ) NOT NULL , `from_uid` BIGINT( 20 ) NOT NULL , `vid` BIGINT( 20 ) NOT NULL , `addtime` VARCHAR( 30 ) NOT NULL , `descr` LONGTEXT NOT NULL , `vkey` VARCHAR( 30 ) NOT NULL , `embed` INT( 1 ) NOT NULL DEFAULT '1', `tags` LONGTEXT NOT NULL , `privacy` VARCHAR( 10 ) NOT NULL , `vlog` INT( 1 ) NOT NULL DEFAULT '0' ) ENGINE = MYISAM ;
CREATE TABLE `playlist_audio` ( `pname` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL , `uid` BIGINT( 20 ) NOT NULL , `from_uid` BIGINT( 20 ) NOT NULL , `vid` BIGINT( 20 ) NOT NULL , `addtime` VARCHAR( 30 ) NOT NULL , `descr` LONGTEXT NOT NULL , `vkey` VARCHAR( 30 ) NOT NULL , `embed` INT( 1 ) NOT NULL DEFAULT '1', `tags` LONGTEXT NOT NULL , `privacy` VARCHAR( 10 ) NOT NULL , `vlog` INT( 1 ) NOT NULL DEFAULT '0' ) ENGINE = MYISAM ;
ALTER TABLE `playlist_video` ADD `active` INT( 1 ) NOT NULL DEFAULT '1';
ALTER TABLE `playlist_image` ADD `active` INT( 1 ) NOT NULL DEFAULT '1';
ALTER TABLE `playlist_audio` ADD `active` INT( 1 ) NOT NULL DEFAULT '1';
ALTER TABLE `playlist_video` CHANGE `pname` `pname` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;
ALTER TABLE `playlist_image` CHANGE `pname` `pname` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;
ALTER TABLE `playlist_audio` CHANGE `pname` `pname` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;
ALTER TABLE `playlist_video` ADD UNIQUE `uni` ( `pname` , `vid` );
ALTER TABLE `playlist_image` ADD UNIQUE `uni` ( `pname` , `vid` );
ALTER TABLE `playlist_audio` ADD UNIQUE `uni` ( `pname` , `vid` );
ALTER TABLE `playlist_video` ADD `views` BIGINT( 20 ) NOT NULL DEFAULT '0';
ALTER TABLE `playlist_image` ADD `views` BIGINT( 20 ) NOT NULL DEFAULT '0';
ALTER TABLE `playlist_audio` ADD `views` BIGINT( 20 ) NOT NULL DEFAULT '0';
ALTER TABLE `playlist_video` ADD `thumb` BIGINT( 20 ) NOT NULL DEFAULT '0';
ALTER TABLE `playlist_image` ADD `thumb` BIGINT( 20 ) NOT NULL DEFAULT '0';
ALTER TABLE `playlist_audio` ADD `thumb` BIGINT( 20 ) NOT NULL DEFAULT '0';
ALTER TABLE `playlist_video` ADD `vlog_time` VARCHAR( 100 ) NOT NULL;
ALTER TABLE `playlist_image` ADD `vlog_time` VARCHAR( 100 ) NOT NULL;
ALTER TABLE `playlist_audio` ADD `vlog_time` VARCHAR( 100 ) NOT NULL;

CREATE TABLE `playlist_files` (
`pid` BIGINT( 20 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`ptype` VARCHAR( 30 ) NOT NULL ,
`vid` BIGINT( 20 ) NOT NULL ,
`uid` BIGINT( 20 ) NOT NULL ,
`position` BIGINT( 20 ) NOT NULL DEFAULT '1', 
`vkey` VARCHAR( 30 ) NOT NULL ,
`active` INT( 1 ) NOT NULL DEFAULT '1'
) ENGINE = MYISAM;
ALTER TABLE `playlist_files` ADD UNIQUE `uni` ( `ptype` , `vid`, `vkey` );

UPDATE `static_files` SET `fname` = 'Signup Table (left)',
`fdescr` = 'The Left Table on the Signup Page',
`fpath` = 'static/signup_table_left.tpl' WHERE `static_files`.`fid` =6 LIMIT 1 ;

CREATE TABLE `request_channel` (
`rid` BIGINT( 20 ) NOT NULL AUTO_INCREMENT PRIMARY KEY,
`uid` BIGINT( 20 ) NOT NULL ,
`from_uid` BIGINT( 20 ) NOT NULL ,
`date` DATETIME NOT NULL ,
`rtype` VARCHAR( 30 ) ,
`solved` INT( 1 ) NOT NULL DEFAULT '0'
) ENGINE = MYISAM;
ALTER TABLE `request_channel` ADD UNIQUE `uni` ( `uid` , `from_uid`, `rtype`, `solved` );
